<!DOCTYPE html>
<html>
    <head>
    <meta http-equiv="refresh" target="_blank" content="3; url=https://www.quickcorp.co.id/">
    <title>MEMBUMI</title>
    <link href="favicon_quickcorp.jpg" rel="icon" alt="logo quick corp" title="logo QuickCorp">
<style>
body, html {
    height: 100%;
    margin: 0;
}


.bgimg {
     background-image: url('quickcorp-bg1.jpg');
     width: 100%;
     height: 100%;
     position: fixed;
     z-index: 1;
     float: left;
     left: 0;
     background-position: center;
     background-size: cover;
     background-repeat: no-repeat;
}

.top-right {
    position: absolute;
    top: 25px;
    right: 16px;
}

.bottomleft {
    position: absolute;
    bottom: 0;
    left: 16px;
}

.middle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

hr {
    margin: auto;
    width: 80%;
}

.ling{
    height:100px;
    width:auto;
}
p {
    color:white;
    font-size:16px;  
        text-shadow: 2px 2px 8px #000000;
}
h1 {
    color:white;
        text-shadow: 2px 2px 8px #000000;
}
h2 {
    color:white;
        text-shadow: 2px 2px 8px #000000;
}
.soc{
    height:30px;
    width:auto;
}


            @font-face {
                font-family: "ZonaPro-Bold";
                src:url('ZonaPro-Bold.otf') format('opentype');
            }

            .digital {
                font-family: "ZonaPro-Bold";
            }

</style>

    </head>
<body>
<div class="bgimg">
  <div class="top-right">
     <a href="https://www.facebook.com/quickcorp.indonesia/"><img class="ling soc" src="fp_quickcorp.png" alt="logo quickcorp"/></a>
     <a href="https://www.instagram.com/quickcorporation/"><img class="ling soc" src="ig_quickcorp.png" alt="logo quickcorp"/></a>
     <a href="https://www.youtube.com/channel/UCQvxRRdfSAQYvE6B-PB8v9g"><img class="ling soc" src="yt_quickcorp.png" alt="logo quickcorp"/></a>
     <a href="https://twitter.com/Quickcorp_id"><img class="ling soc" src="tw_quickcorp.png" alt="logo quickcorp"/></a>
  </div>
  <div class="middle digital">
    <a href="https://www.quickcorp.co.id/produk.php"><img class="ling" src="logo_quickcorp.png" alt="logo quickcorp"/></a>
    <br><hr/>
    <marquee>
        <h1>Siap Melayani Semua Kebutuhan Usaha Anda</h1>
    </marquee>
    <hr/>
    <h2>| Pusat Percetakan | Advertising | Merchandise | Stempel | Konveksi dan Desain Grafis |</h2>
  </div>
  <div class="bottomleft digital">
    <p>Kunjungi Website Resmi Kami <a style="text-decoration:none;" href="https://www.quickcorp.co.id">QUICK CORP.</a></p>
  </div>
</div>

<script>
// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2019 15:37:25").getTime();

// Update the count down every 1 second
var countdownfunction = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance = countDownDate - now;
    
    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("demo").innerHTML = days + "d " + hours + "h "
    + minutes + "m " + seconds + "s ";
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(countdownfunction);
        document.getElementById("demo").innerHTML = "EXPIRED";
    }
}, 1000);
</script>

</body>
</html>
